﻿// ReoScript Console Demo
//
// copyright (c) 2013 unvell all rights reserved

console.log('hello console!');