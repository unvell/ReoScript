﻿// ReoScript v1.0 (LGPLv3)
//
// copyright(c) unvell 2013 all rights reserved.
//

console.log('hello world!');