﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Unvell.ReoScript;

namespace SimplestApplication
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// initialize script interpreter
			ScriptRunningMachine srm = new ScriptRunningMachine();

			// execute script (Don't forget the semicolon at end)
			srm.Run("alert('hello world!');");
		}
	}
}
