﻿// ReoScript v1.0
//
// copyright(c) unvell 2013 all rights reserved.
//

console.log('hello world!');
