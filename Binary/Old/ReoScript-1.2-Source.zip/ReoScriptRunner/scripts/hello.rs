﻿
// ReoScript

console.log('Hello World!');
